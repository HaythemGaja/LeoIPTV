# Leo IPTV 2.3 for Android TV

Leo IPTV plays channels, movies and series from your Xtream Codes account or M3U playlist. Sign in or add a playlist on the TV. Artwork and listings come from your provider.

## Hold & browse

Watching a match during a break? Highlight **Hold & browse** in the player and press OK. Browse other channels, play a film, or search. A **Return to [channel]** shortcut shows exactly where you came from and how long you have been away. Select it to rejoin the live broadcast.

Hold OK on **Hold & browse** to choose a 2-, 5-, or 10-minute reminder. Leo IPTV shows the reminder while the app is open. You choose when to return. A successful return clears the shortcut. A failed connection leaves it available for retry. Hold OK on the shortcut while browsing to release it. Each profile has its own held channel, which survives an app restart.

## Browsing with a remote

- On the dashboard, use Up and Down in the sidebar. OK opens a section. Right moves to the featured action. Continue Watching and Recently Played use artwork from your viewing history.
- In Live TV, Movies or Series, select a category with OK. Press Right to enter the titles. Left and Right move along the row, including across page boundaries. Left from the first title returns to the sidebar. Back from any content row goes straight to the return shortcut when one exists, or to the sidebar. Another Back takes you to the dashboard.
- Up and Down move between the title row, its playback or detail button, and available shelves. Back from the player restores the browsing selection when the item is still present.
- In the guide, choose a category and press Right to browse its channels. Press OK to watch. Now and Next appear when the provider supplies schedules.
- In the player, use Left and Right to highlight a control, then press OK. Movies and episodes have 30-second skip buttons. Up and Down switch items in the playback queue. Menu toggles a favorite. Back returns to browsing.
- Settings lets you choose three to six items per row. New installations start with three for larger artwork. Existing density preferences are respected.

## Build on GitHub

With the project files at the root of a GitHub repository, open **Actions → Build Android TV APK → Run workflow**. The successful run provides the **LeoIPTV-Android-TV** artifact containing the signed APK. To reuse your existing Android debug signing key across builds, provide its base64 contents in the optional Actions secret `LEO_DEBUG_KEYSTORE_B64`. Otherwise each hosted build uses the runner's debug key.

## Build the APK locally

Use Bash on Linux or WSL with a JDK 17 or later, the Android SDK, and the `zip` utility. Install Android SDK Platform 34 and Android SDK Build Tools 34.0.0. Set `ANDROID_HOME` to that SDK, and put the JDK on your PATH or set `JAVA_HOME`. The original sibling directories `../sdk` and `../jdk` also work.

```sh
./build-apk.sh
```

The script compiles the resources and Java sources, signs the APK and verifies its signature and alignment. The output is `build/out/LeoIPTV-v2.3.apk`. Package `com.leo.iptv`, version code 6, minimum Android 7 (API 24), target API 34.

To update an existing installation in place, build with the same signing key as that installation. The script uses `../debug.keystore` when present, then the user's standard Android debug keystore. Set `LEO_DEBUG_KEYSTORE` to select an existing debug keystore with the standard Android debug password.

With the TV connected through ADB, install the verified build with:

```sh
adb install -r build/out/LeoIPTV-v2.3.apk
```
