package com.leo.iptv;

import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

final class Artwork {
    static void bind(ImageView image, TextView initials, Item item) {
        ((View)image.getParent()).setClipToOutline(true);
        initials.setVisibility(View.VISIBLE);
        initials.setText(item.initials());
        int base = item.color();
        int shade = android.graphics.Color.rgb(android.graphics.Color.red(base) / 3,
                android.graphics.Color.green(base) / 3, android.graphics.Color.blue(base) / 3);
        initials.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{base, shade}));
        image.setScaleType(item.isLive() ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
        image.setVisibility(View.VISIBLE);
        LogoCache.load(item.logo, image, 0);
    }
}
