package com.leo.iptv;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

public class DashboardActivity extends Activity {
    private ReturnTicket returnTicket;
    private LinearLayout recentList, cwList;
    private Button open;
    private int lastNav = R.id.tile_live;

    public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_dashboard);
        returnTicket = new ReturnTicket(this);
        recentList = findViewById(R.id.recent_list);
        cwList = findViewById(R.id.cw_list);
        open = findViewById(R.id.dash_open);
        bindNav(R.id.tile_live, BrowseActivity.class, "LIVE");
        bindNav(R.id.tile_movies, BrowseActivity.class, "MOVIE");
        bindNav(R.id.tile_series, BrowseActivity.class, "SERIES");
        bindNav(R.id.tile_guide, GuideActivity.class, null);
        bindNav(R.id.tile_fav, BrowseActivity.class, "FAV");
        bindNav(R.id.tile_search, SearchActivity.class, null);
        bindNav(R.id.tile_settings, SettingsActivity.class, null);
        bindNav(R.id.tile_switch, LoginActivity.class, null);
        View ticket = findViewById(R.id.return_ticket);
        ticket.setNextFocusRightId(R.id.dash_open);
        open.setOnKeyListener((v, key, event) -> returnToNav(key, event));
        if (state == null) findViewById(lastNav).requestFocus();
    }
    private void bindNav(int id, Class<?> screen, String mode) {
        View link = findViewById(id);
        link.setOnFocusChangeListener((v, focused) -> { if (focused) lastNav = id; });
        link.setNextFocusRightId(R.id.dash_open);
        link.setOnClickListener(v -> {
            Intent intent = new Intent(this, screen);
            if (mode != null) intent.putExtra("mode", mode);
            if (id == R.id.tile_switch) Prefs.setCurrent(this, "");
            startActivity(intent);
            if (id == R.id.tile_switch) finish();
        });
    }
    private boolean returnToNav(int key, KeyEvent event) {
        return key == KeyEvent.KEYCODE_DPAD_LEFT && event.getAction() == KeyEvent.ACTION_DOWN
                && findViewById(lastNav).requestFocus();
    }
    protected void onResume() {
        super.onResume();
        returnTicket.refresh();
        Profile profile = Prefs.current(this);
        if (profile == null) { startActivity(new Intent(this, LoginActivity.class)); finish(); return; }
        ((TextView)findViewById(R.id.dash_name)).setText(profile.name);
        ((TextView)findViewById(R.id.dash_account)).setText(profile.accountLine.isEmpty()
                ? (profile.isXtream() ? "Xtream Codes" : "M3U playlist") : profile.accountLine);
        View before = getCurrentFocus();
        LinearLayout activeRow = before != null && (before.getParent() == cwList || before.getParent() == recentList)
                ? (LinearLayout)before.getParent() : null;
        Object previousKey = activeRow == null ? null : before.getTag();
        List<Item> recent = Prefs.recent(this);
        List<ProgressStore.Entry> progress = ProgressStore.load(this);
        java.util.Collections.sort(progress, (a,b) -> Long.compare(b.updated, a.updated));
        Item spotlight = recent.isEmpty() ? null : recent.get(0);
        TextView title = findViewById(R.id.dash_headline);
        ImageView art = findViewById(R.id.dash_art);
        title.setText(spotlight == null ? "Live TV" : spotlight.name);
        View hero = (View)art.getParent();
        hero.setClipToOutline(true);
        art.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LogoCache.load(spotlight == null ? "" : spotlight.logo, art, R.drawable.signal_art);
        open.setText(spotlight == null ? "Browse channels" : "Watch again");
        open.setOnClickListener(v -> {
            if (spotlight == null) findViewById(R.id.tile_live).performClick();
            else {
                int resume = 0;
                for (ProgressStore.Entry entry : progress)
                    if (entry.item.key().equals(spotlight.key())) { resume = entry.position; break; }
                Play.playOneResume(this, spotlight, resume);
            }
        });
        recentList.removeAllViews();
        cwList.removeAllViews();
        for (int i=0; i<Math.min(10,progress.size()); i++) {
            ProgressStore.Entry entry = progress.get(i);
            addItem(cwList,entry.item,entry);
        }
        for (Item item : recent) addItem(recentList,item,null);
        emptyMessage(cwList,"Movies and episodes you start will appear here.");
        emptyMessage(recentList,"Channels and titles you play will appear here.");
        if (activeRow != null) {
            View restore = activeRow.findViewWithTag(previousKey);
            if (restore == null || !restore.requestFocus()) open.requestFocus();
        }
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void emptyMessage(LinearLayout row, String message) {
        if (row.getChildCount() > 0) return;
        TextView note = new TextView(this);
        note.setText(message);
        note.setTextColor(getColor(R.color.leo_text_muted));
        note.setTextSize(15);
        row.addView(note);
    }
    private void addItem(LinearLayout row, Item item, ProgressStore.Entry progress) {
        View card = getLayoutInflater().inflate(R.layout.grid_item,row,false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(164), -2);
        lp.rightMargin = dp(10);
        card.setLayoutParams(lp);
        View box = card.findViewById(R.id.poster_box);
        box.getLayoutParams().height = dp(item.isLive() ? 96 : 192);
        Artwork.bind(card.findViewById(R.id.logo), card.findViewById(R.id.tile), item);
        ((TextView)card.findViewById(R.id.item_name)).setText(item.name);
        ((TextView)card.findViewById(R.id.item_group)).setText(progress == null ? item.group
                : ProgressStore.fmtLeft(progress.position, progress.duration));
        card.findViewById(R.id.item_now).setVisibility(View.GONE);
        if (progress != null) {
            android.widget.ProgressBar bar = card.findViewById(R.id.item_progress);
            bar.setVisibility(View.VISIBLE);
            bar.setProgress(progress.pct());
        }
        card.setTag(item.key());
        if (row.getChildCount() == 0) card.setOnKeyListener((v,k,e) -> returnToNav(k,e));
        card.setOnClickListener(v -> Play.playOneResume(this, item, progress == null ? 0 : progress.position));
        row.addView(card);
    }
    protected void onPause() {
        returnTicket.pause();
        super.onPause();
    }
}
