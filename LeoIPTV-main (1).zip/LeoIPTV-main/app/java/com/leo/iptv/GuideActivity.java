package com.leo.iptv;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

// TV Guide: real short-EPG only, fetched on demand for the selected category
// only, one request per channel, cached for the session (Api.epgCache).
public class GuideActivity extends Activity {
    private ReturnTicket returnTicket;
    private Profile profile;
    private ListView catList, chanList;
    private TextView statusView;
    private List<Api.Cat> cats = new ArrayList<Api.Cat>();
    private List<Item> channels = new ArrayList<Item>();
    private int categoryRequest;
    private List<Item> allM3u = new ArrayList<Item>();
    private BaseAdapter adapter;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_guide);
        returnTicket = new ReturnTicket(this);
        profile = Prefs.current(this);
        catList = (ListView) findViewById(R.id.g_cats);
        chanList = (ListView) findViewById(R.id.g_chans);
        statusView = (TextView) findViewById(R.id.g_status);
        if (profile == null) { finish(); return; }
        adapter = new BaseAdapter() {
            public int getCount() { return channels.size(); }
            public Object getItem(int p) { return channels.get(p); }
            public long getItemId(int p) { return p; }
            public View getView(int pos, View cv, ViewGroup parent) {
                View v = cv;
                if (v == null) v = getLayoutInflater().inflate(R.layout.guide_row, parent, false);
                bindChannel(v, channels.get(pos));
                return v;
            }
        };
        chanList.setAdapter(adapter);
        chanList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                Play.play(GuideActivity.this, channels, pos);
            }
        });
        catList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                if (profile.isXtream()) loadChannels(pos == 0 ? null : cats.get(pos - 1).id);
                else loadM3uChannels(pos == 0 ? "All" : ((String) p.getItemAtPosition(pos)));
            }
        });
        statusView.setText("Loading categories…");
        if (profile.isXtream()) {
            Api.categories(profile, "LIVE", new Api.Cb<List<Api.Cat>>() {
                public void done(final List<Api.Cat> cs, final String err) {
                    runOnUiThread(new Runnable() { public void run() {
                        if (err != null) { statusView.setText(err); return; }
                        cats = cs;
                        List<String> names = new ArrayList<String>();
                        names.add("All categories");
                        for (Api.Cat c : cs) names.add(c.name);
                        catList.setAdapter(new ArrayAdapter<String>(GuideActivity.this,
                                android.R.layout.simple_list_item_1, names));
                        loadChannels(null);
                    }});
                }
            });
        } else {
            Api.loadM3u(profile.m3uUrl, new Api.Cb<List<Item>>() {
                public void done(final List<Item> items, final String err) {
                    runOnUiThread(new Runnable() { public void run() {
                        if (err != null) { statusView.setText(err); return; }
                        allM3u = items;
                        List<String> groups = new ArrayList<String>();
                        groups.add("All categories");
                        for (Item it : items)
                            if (it.isLive() && !groups.contains(it.group)) groups.add(it.group);
                        catList.setAdapter(new ArrayAdapter<String>(GuideActivity.this,
                                android.R.layout.simple_list_item_1, groups));
                        loadM3uChannels("All");
                    }});
                }
            });
        }
    }
    private void loadChannels(String catId) {
        final int request = ++categoryRequest;
        channels = new ArrayList<Item>();
        adapter.notifyDataSetChanged();
        statusView.setText("Loading channels…");
        Api.streams(profile, "LIVE", catId, new Api.Cb<List<Item>>() {
            public void done(final List<Item> items, final String err) {
                runOnUiThread(new Runnable() { public void run() {
                    if (request != categoryRequest || isFinishing() || isDestroyed()) return;
                    if (err != null) { statusView.setText(err); return; }
                    setChannels(items);
                }});
            }
        });
    }
    private void loadM3uChannels(String group) {
        List<Item> out = new ArrayList<Item>();
        for (Item it : allM3u) {
            if (!it.isLive()) continue;
            if (!"All".equals(group) && !it.group.equals(group)) continue;
            out.add(it);
        }
        setChannels(out);
    }
    private void setChannels(List<Item> items) {
        channels = items;
        adapter.notifyDataSetChanged();
        if (!items.isEmpty()) chanList.setSelection(0);
        statusView.setText(channels.isEmpty() ? "No channels in this category." : channels.size() + " channels");
    }
    private void bindChannel(View row, Item channel) {
        ((TextView)row.findViewById(R.id.g_name)).setText(channel.name);
        TextView now = row.findViewById(R.id.g_epg);
        TextView next = row.findViewById(R.id.g_next);
        row.setTag(channel);
        next.setText("");
        if (!profile.isXtream() || channel.id.isEmpty()) {
            now.setText("No guide data from this provider");
            return;
        }
        now.setText("Loading guide…");
        Api.shortEpg(profile, channel.id, (epg, error) -> runOnUiThread(() -> {
            if (row.getTag() != channel) return;
            now.setText(epg.now.isEmpty() ? "No guide data from this provider" : "Now: " + epg.now);
            next.setText(epg.next.isEmpty() ? "" : "Next: " + epg.next);
        }));
    }
    protected void onResume() {
        super.onResume();
        returnTicket.refresh();
    }
    protected void onPause() {
        returnTicket.pause();
        super.onPause();
    }
}
