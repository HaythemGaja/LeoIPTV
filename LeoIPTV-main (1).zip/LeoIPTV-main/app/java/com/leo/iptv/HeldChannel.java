package com.leo.iptv;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.UUID;

/** One live-channel detour per profile. Looking at other channels never changes the hold. */
final class HeldChannel {
    final Item item;
    final long since;
    final String token;
    final long remindAt;
    final boolean reminded;

    private HeldChannel(Item item, long since, String token, long remindAt, boolean reminded) {
        this.item = item;
        this.since = since;
        this.token = token;
        this.remindAt = remindAt;
        this.reminded = reminded;
    }
    private static SharedPreferences store(Context context) {
        return context.getSharedPreferences("leo_held_channels", Context.MODE_PRIVATE);
    }
    static HeldChannel get(Context context, String profile) {
        String json = store(context).getString(profile, "");
        if (json.isEmpty()) return null;
        try {
            JSONObject entry = new JSONObject(json);
            Item item = Item.fromJson(entry.getJSONObject("channel"));
            if (!item.isLive() || item.url.isEmpty()) return null;
            return new HeldChannel(item, entry.getLong("since"), entry.getString("token"),
                    entry.optLong("remindAt", 0), entry.optBoolean("reminded", false));
        } catch (JSONException ignored) { return null; }
    }
    static boolean hold(Context context, String profile, Item item, int reminderMinutes) {
        if (profile.isEmpty() || item == null || !item.isLive() || item.url.isEmpty()) return false;
        try {
            JSONObject entry = new JSONObject();
            entry.put("channel", item.toJson());
            long since = System.currentTimeMillis();
            entry.put("since", since);
            if (reminderMinutes > 0) entry.put("remindAt", since + reminderMinutes * 60000L);
            entry.put("token", UUID.randomUUID().toString());
            store(context).edit().putString(profile, entry.toString()).apply();
            return true;
        } catch (JSONException ignored) { return false; }
    }
    static void clear(Context context, String profile) {
        store(context).edit().remove(profile).apply();
    }
    static void clearIfCurrent(Context context, String profile, String token) {
        HeldChannel held = get(context, profile);
        if (held != null && held.token.equals(token)) clear(context, profile);
    }
    // All callers run on the main thread. A timer is acknowledged once per hold,
    // even when the viewer switches screens at the moment it expires.
    void notifyIfDue(Context context, String profile, long now) {
        if (remindAt == 0 || now < remindAt || reminded) return;
        try {
            JSONObject entry = new JSONObject(store(context).getString(profile, ""));
            if (!token.equals(entry.optString("token")) || entry.optBoolean("reminded", false)) return;
            entry.put("reminded", true);
            store(context).edit().putString(profile, entry.toString()).apply();
            android.widget.Toast.makeText(context, "Time to check " + item.name,
                    android.widget.Toast.LENGTH_LONG).show();
        } catch (JSONException ignored) { }
    }
    String status(long now) {
        if (remindAt > 0) {
            if (now >= remindAt) return "Reminder due";
            long minutes = (remindAt - now + 59999) / 60000;
            return "Reminder in " + minutes + " min";
        }
        return elapsed(now);
    }
    long nextUpdate(long now) {
        if (remindAt > now) return Math.min(60000, remindAt - now);
        long elapsed = Math.max(0, now - since);
        return 60000 - elapsed % 60000;
    }
    String elapsed(long now) {
        long minutes = Math.max(0, now - since) / 60000;
        if (minutes == 0) return "Just left";
        if (minutes < 60) return minutes + " min away";
        if (minutes < 1440) return minutes / 60 + " h away";
        return minutes / 1440 + " d away";
    }
}
