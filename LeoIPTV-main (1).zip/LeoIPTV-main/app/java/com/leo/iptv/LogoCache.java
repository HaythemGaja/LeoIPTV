package com.leo.iptv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LogoCache {
    private static final ExecutorService workers = Executors.newFixedThreadPool(4);
    private static final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        protected int sizeOf(String key, Bitmap bitmap) { return bitmap.getByteCount(); }
    };

    public static void load(String url, ImageView view, int placeholder) {
        view.setTag(url);
        Bitmap cached = url.isEmpty() ? null : cache.get(url);
        if (cached != null) { display(view, cached, placeholder); return; }
        view.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        view.setImageResource(placeholder);
        if (url.isEmpty()) return;
        workers.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection)new URL(url).openConnection();
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(8000);
                try (InputStream stream = connection.getInputStream()) {
                    Bitmap bitmap = BitmapFactory.decodeStream(stream);
                    if (bitmap == null) return;
                    cache.put(url, bitmap);
                    view.post(() -> {
                        if (url.equals(view.getTag())) display(view, bitmap, placeholder);
                    });
                }
            } catch (Exception ignored) {
                // Keep the local artwork if this provider's image is unavailable.
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }
    private static void display(ImageView view, Bitmap image, int placeholder) {
        if (placeholder == 0) view.setBackgroundColor(0xFF192535);
        view.setImageBitmap(image);
    }
}
