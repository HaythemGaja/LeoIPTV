package com.leo.iptv;

import android.app.Activity;
import android.content.Intent;
import android.util.AtomicFile;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Keep a large provider catalog out of the activity transaction. The selected
// item travels with the intent, so it can play even if Android evicts the cache.
public class Play {
    private static String activeId;
    private static List<Item> activeItems;
    private static final ExecutorService storage = Executors.newSingleThreadExecutor();

    public static void play(Activity activity, List<Item> items, int pos) {
        playWithResume(activity, items, pos, 0);
    }
    public static void playWithResume(Activity activity, List<Item> items, int pos, int resumeMs) {
        if (pos < 0 || pos >= items.size()) return;
        Intent intent = new Intent(activity, PlayerActivity.class);
        intent.putExtra("items", Item.listToJson(Collections.singletonList(items.get(pos))));
        if (items.size() > 1) {
            String id = UUID.randomUUID().toString();
            List<Item> snapshot = new ArrayList<>(items);
            activeId = id;
            activeItems = snapshot;
            intent.putExtra("queue", id);
            intent.putExtra("pos", pos);
            AtomicFile file = queueFile(activity, id);
            storage.execute(() -> {
                FileOutputStream out = null;
                try {
                    out = file.startWrite();
                    out.write(Item.listToJson(snapshot).getBytes(StandardCharsets.UTF_8));
                    file.finishWrite(out);
                } catch (IOException error) {
                    if (out != null) file.failWrite(out);
                }
            });
        }
        intent.putExtra("resume", resumeMs);
        intent.putExtra("profile", Prefs.currentName(activity));
        activity.startActivity(intent);
    }
    static void returnToChannel(Activity screen, HeldChannel held) {
        Intent intent = new Intent(screen, PlayerActivity.class);
        intent.putExtra("items", Item.listToJson(Collections.singletonList(held.item)));
        intent.putExtra("profile", Prefs.currentName(screen));
        intent.putExtra("returnToken", held.token);
        screen.startActivity(intent);
        if (screen instanceof PlayerActivity) screen.finish();
    }
    private static AtomicFile queueFile(Activity activity, String id) {
        return new AtomicFile(new File(activity.getCacheDir(), "play-" + id + ".json"));
    }
    static List<Item> readQueue(Activity activity) {
        Intent intent = activity.getIntent();
        String id = intent.getStringExtra("queue");
        if (id != null) {
            if (id.equals(activeId)) return activeItems;
            try (FileInputStream in = queueFile(activity, id).openRead()) {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                byte[] block = new byte[8192];
                int n;
                while ((n = in.read(block)) != -1) bytes.write(block, 0, n);
                List<Item> restored = Item.listFromJson(bytes.toString("UTF-8"));
                if (!restored.isEmpty()) return restored;
            } catch (IOException ignored) { }
        }
        return Item.listFromJson(intent.getStringExtra("items"));
    }
    static void release(Activity activity) {
        String id = activity.getIntent().getStringExtra("queue");
        if (id == null) return;
        if (id.equals(activeId)) { activeId = null; activeItems = null; }
        AtomicFile file = queueFile(activity, id);
        storage.execute(file::delete);
    }
    public static void playOne(Activity activity, Item item) {
        playOneResume(activity, item, 0);
    }
    public static void playOneResume(Activity activity, Item item, int resumeMs) {
        playWithResume(activity, Collections.singletonList(item), 0, resumeMs);
    }
}
