package com.leo.iptv;

import android.app.Activity;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// v2.1: a real media player. The transport row is always visible: Play/Pause
// button, seek bar (VOD only — live shows a LIVE badge instead), current /
// total time, and Favorite. A spinner shows while loading or buffering, the
// stream is sent the provider User-Agent header, and a failed stream offers
// a Retry button. Left/Right traverses transport buttons; Up/Down changes
// the queue item, MENU toggles favorite, and Back returns to the library.
public class PlayerActivity extends Activity {
    private VideoView video;
    private TextView nameView, groupView, nowView, progressView, liveView, errorView;
    private Button favBtn, playBtn, retryBtn;
    private SeekBar seekBar;
    private Button rewindBtn, forwardBtn, holdBtn;
    private TextView controlsHint;
    private String profileName;
    private HeldChannel playerHold;
    private boolean foreground;
    private final Runnable holdClock = new Runnable() {
        public void run() {
            if (!foreground || playerHold == null) return;
            long now = System.currentTimeMillis();
            playerHold.notifyIfDue(PlayerActivity.this, profileName, now);
            controlsHint.setText("Held channel   •   " + playerHold.item.name + "   •   " + playerHold.status(now));
            handler.postDelayed(this, playerHold.nextUpdate(now));
        }
    };
    private ProgressBar loading;
    private LinearLayout errorPanel;
    private List<Item> items;
    private Profile profile;
    private int pos = 0;
    private boolean prepared = false;
    private boolean audioOnlyReturn;
    private boolean dragging = false;
    // v2.2: resume position (ms) for VOD, from Continue Watching. 0 = start.
    private int resumeMs = 0;
    private boolean resumed = false;
    private int saveTick = 0;
    private Handler handler = new Handler();
    private Runnable progressTick = new Runnable() {
        public void run() {
            Item it = current();
            if (it != null) {
                if (it.isLive()) {
                    progressView.setText("Live");
                    if (audioOnlyReturn && prepared && video.isPlaying() && video.getCurrentPosition() > 0)
                        completeReturn();
                }
                else if (video.getDuration() > 0) {
                    progressView.setText(fmt(video.getCurrentPosition()) + " / " + fmt(video.getDuration()));
                    if (prepared && !dragging) seekBar.setProgress(video.getCurrentPosition());
                    // v2.2: save progress every ~15s while playing.
                    if (prepared && video.isPlaying() && ++saveTick >= 15) {
                        saveTick = 0;
                        saveProgress();
                    }
                } else progressView.setText("Loading…");
            }
            handler.postDelayed(this, 1000);
        }
    };
    // v2.2: persist the current VOD position (live is never tracked).
    // ProgressStore drops the entry when finished (>= 90%) or barely
    // started (< 10s), so this one call covers pause, exit and completion.
    private void saveProgress() {
        Item it = current();
        if (it == null || it.isLive() || !prepared) return;
        int dur = 0, posMs = 0;
        try { dur = video.getDuration(); posMs = video.getCurrentPosition(); } catch (Exception ignored) {}
        if (dur > 0 && posMs > 0)
            ProgressStore.save(this, it, posMs, dur, profile != null ? profile.name : "");
    }
    private static String fmt(int ms) {
        int s = ms / 1000;
        return String.format("%d:%02d", s / 60, s % 60);
    }
    private Item current() {
        if (items == null || items.isEmpty() || pos < 0 || pos >= items.size()) return null;
        return items.get(pos);
    }

    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_player);
        video = (VideoView) findViewById(R.id.video);
        nameView = (TextView) findViewById(R.id.p_name);
        groupView = (TextView) findViewById(R.id.p_group);
        nowView = (TextView) findViewById(R.id.p_now);
        progressView = (TextView) findViewById(R.id.p_progress);
        liveView = (TextView) findViewById(R.id.p_live);
        errorView = (TextView) findViewById(R.id.error_box);
        errorPanel = (LinearLayout) findViewById(R.id.error_panel);
        loading = (ProgressBar) findViewById(R.id.p_loading);
        favBtn = (Button) findViewById(R.id.btn_fav);
        playBtn = (Button) findViewById(R.id.btn_play);
        retryBtn = (Button) findViewById(R.id.btn_retry);
        seekBar = (SeekBar) findViewById(R.id.seek_bar);
        holdBtn = findViewById(R.id.btn_hold);
        controlsHint = findViewById(R.id.p_controls_hint);
        holdBtn.setOnClickListener(v -> useHold(0));
        holdBtn.setOnLongClickListener(v -> {
            if (current() == null || !current().isLive() || HeldChannel.get(this, profileName) != null) return false;
            new android.app.AlertDialog.Builder(this).setTitle("When should we remind you?")
                    .setItems(new String[]{"In 2 minutes", "In 5 minutes", "In 10 minutes"},
                            (dialog, choice) -> useHold(new int[]{2, 5, 10}[choice]))
                    .setNegativeButton("Cancel", null).show();
            return true;
        });
        rewindBtn = findViewById(R.id.btn_rewind);
        forwardBtn = findViewById(R.id.btn_forward);
        rewindBtn.setOnClickListener(v -> seekBy(-30000));
        forwardBtn.setOnClickListener(v -> seekBy(30000));
        items = Play.readQueue(this);
        pos = b == null ? getIntent().getIntExtra("pos", 0) : b.getInt("queuePosition", 0);
        if (pos < 0 || pos >= items.size()) pos = 0;
        resumeMs = b == null ? getIntent().getIntExtra("resume", 0) : b.getInt("playbackPosition", 0);
        String profName = getIntent().getStringExtra("profile");
        profileName = profName == null ? Prefs.currentName(this) : profName;
        if (profName != null) {
            for (Profile p : Prefs.profiles(this)) if (p.name.equals(profName)) profile = p;
        }
        video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mp) {
                prepared = true;
                loading.setVisibility(View.GONE);
                Item it = current();
                if (it != null && !it.isLive() && video.getDuration() > 0) {
                    seekBar.setMax(video.getDuration());
                    seekBar.setKeyProgressIncrement(30000);
                    seekBar.setVisibility(View.VISIBLE);
                    rewindBtn.setVisibility(View.VISIBLE);
                    forwardBtn.setVisibility(View.VISIBLE);
                    // v2.2: resume where Continue Watching left off.
                    if (!resumed && resumeMs > 0 && resumeMs < video.getDuration()) {
                        resumed = true;
                        video.seekTo(resumeMs);
                        progressView.setText("Resuming from " + fmt(resumeMs));
                    }
                    // Resume applies once, to the first item only — clear it so
                    // switching channels with UP/DOWN never seeks the new item
                    // to the old item's position.
                    resumeMs = 0;
                } else {
                    seekBar.setVisibility(View.GONE);
                }
                video.start();
                if (getIntent().hasExtra("returnToken")) {
                    try {
                        boolean audio = false, picture = false;
                        for (MediaPlayer.TrackInfo track : mp.getTrackInfo()) {
                            audio |= track.getTrackType() == MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO;
                            picture |= track.getTrackType() == MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_VIDEO;
                        }
                        audioOnlyReturn = audio && !picture;
                    } catch (RuntimeException ignored) { }
                }
                updateHold();
                updatePlayLabel();
            }
        });
        video.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            public boolean onInfo(MediaPlayer mp, int what, int extra) {
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) completeReturn();
                if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START)
                    loading.setVisibility(View.VISIBLE);
                else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END)
                    loading.setVisibility(View.GONE);
                return true;
            }
        });
        video.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            public boolean onError(MediaPlayer mp, int what, int extra) {
                prepared = false;
                loading.setVisibility(View.GONE);
                showError(current());
                return true;
            }
        });
        video.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {
                // v2.2: finished — ProgressStore drops the entry (>= 90%).
                saveProgress();
                updatePlayLabel();
            }
        });
        playBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { togglePlay(); }
        });
        favBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Item it = current();
                if (it == null) return;
                Prefs.toggleFav(PlayerActivity.this, it);
                updateFavLabel();
            }
        });
        retryBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                playBtn.requestFocus();
                playCurrent();
            }
        });
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                if (fromUser && prepared) {
                    try { video.seekTo(progress); } catch (Exception ignored) {}
                }
            }
            public void onStartTrackingTouch(SeekBar s) { dragging = true; }
            public void onStopTrackingTouch(SeekBar s) { dragging = false; }
        });
        playBtn.requestFocus();
        playCurrent();
        progressTick.run();
    }
    protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putInt("queuePosition", pos);
        state.putInt("playbackPosition", prepared ? video.getCurrentPosition() : resumeMs);
    }
    protected void onDestroy() {
        super.onDestroy();
        saveProgress();
        handler.removeCallbacks(progressTick);
        if (isFinishing()) Play.release(this);
    }
    protected void onResume() {
        super.onResume();
        foreground = true;
        updateHold();
    }
    protected void onPause() {
        super.onPause();
        foreground = false;
        handler.removeCallbacks(holdClock);
        // v2.2: keep the resume point when leaving the player.
        saveProgress();
        try { video.pause(); } catch (Exception ignored) {}
    }

    private void showError(Item it) {
        // v2.2: hide the spinner here too — the setVideoURI-throws path used
        // to leave it spinning over the error panel.
        loading.setVisibility(View.GONE);
        String host = it == null ? "unknown host" : hostOf(it.url);
        errorView.setText("Could not play this stream.\nHost: " + host
                + "\n\nTry another channel, or press BACK to return.");
        errorPanel.setVisibility(View.VISIBLE);
        retryBtn.requestFocus();
    }
    private void updateFavLabel() {
        Item it = current();
        favBtn.setText(it != null && Prefs.isFav(this, it) ? "★ Favorite" : "☆ Favorite");
    }
    private void completeReturn() {
        String token = getIntent().getStringExtra("returnToken");
        if (token == null) return;
        HeldChannel.clearIfCurrent(this, profileName, token);
        getIntent().removeExtra("returnToken");
        audioOnlyReturn = false;
        updateHold();
    }
    private void updateHold() {
        handler.removeCallbacks(holdClock);
        playerHold = HeldChannel.get(this, profileName);
        HeldChannel held = playerHold;
        Item item = current();
        boolean live = item != null && item.isLive();
        holdBtn.setVisibility(live || held != null ? View.VISIBLE : View.GONE);
        boolean same = held != null && item != null && held.item.key().equals(item.key());
        holdBtn.setText(held == null ? "Hold & browse" : same ? "Browse again" : "Return to " + held.item.name);
        controlsHint.setText(held == null && live
                ? "Hold & browse saves your way back. Hold OK on that button to add a reminder."
                : held != null ? "Held channel   •   " + held.item.name + "   •   " + held.status(System.currentTimeMillis())
                : "Left / Right   Controls     •     OK   Select     •     Back   Return");
        if (foreground && held != null) holdClock.run();
    }
    private void useHold(int reminderMinutes) {
        Item item = current();
        if (item == null) return;
        HeldChannel held = HeldChannel.get(this, profileName);
        if (held != null && !held.item.key().equals(item.key())) {
            saveProgress();
            prepared = false;
            video.stopPlayback();
            Play.returnToChannel(this, held);
            return;
        }
        if (held != null || HeldChannel.hold(this, profileName, item, reminderMinutes)) {
            android.widget.Toast.makeText(this, "Held " + item.name, android.widget.Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    private void updatePlayLabel() {
        boolean playing = false;
        try { playing = video.isPlaying(); } catch (Exception ignored) {}
        playBtn.setText(playing ? "Pause" : "Play");
    }
    private void togglePlay() {
        try {
            if (video.isPlaying()) video.pause(); else video.start();
        } catch (Exception ignored) {}
        updatePlayLabel();
    }
    private void playCurrent() {
        // Channel changes save the outgoing position before advancing the queue.
        final Item it = current();
        if (it == null) { finish(); return; }
        prepared = false;
        resumed = false;
        audioOnlyReturn = false;
        saveTick = 0;
        if (rewindBtn.hasFocus() || forwardBtn.hasFocus() || retryBtn.hasFocus()) playBtn.requestFocus();
        rewindBtn.setVisibility(View.GONE);
        forwardBtn.setVisibility(View.GONE);
        errorPanel.setVisibility(View.GONE);
        loading.setVisibility(View.VISIBLE);
        seekBar.setVisibility(View.GONE);
        nameView.setText(it.name);
        groupView.setText(it.group + " • " + it.type);
        liveView.setVisibility(it.isLive() ? View.VISIBLE : View.GONE);
        updateFavLabel();
        updateHold();
        updatePlayLabel();
        Prefs.addRecent(this, it);
        // Real guide only: Xtream short EPG for this stream, else the honest line.
        if (it.isLive() && profile != null && profile.isXtream() && it.id.length() > 0) {
            nowView.setText("Loading guide…");
            Api.shortEpg(profile, it.id, new Api.Cb<Api.Epg>() {
                public void done(final Api.Epg e, String err) {
                    runOnUiThread(new Runnable() { public void run() {
                        if (current() != it) return;
                        if (e.now.length() > 0)
                            nowView.setText("Now: " + e.now + (e.next.length() > 0 ? "\nNext: " + e.next : ""));
                        else nowView.setText("No guide data from this provider");
                    }});
                }
            });
        } else if (it.isLive()) {
            nowView.setText("No guide data from this provider");
        } else {
            nowView.setText(it.plot.length() > 0 ? it.plot : "");
        }
        try {
            // Some providers reject streams without a User-Agent; send the
            // same one the API calls use.
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("User-Agent", Api.USER_AGENT);
            video.stopPlayback();
            video.setVideoURI(Uri.parse(it.url), headers);
            // Playback starts in onPrepared.
        } catch (Exception e) { showError(it); }
    }
    private void seekBy(int delta) {
        if (prepared && video.getDuration() > 0) {
            long target = (long)video.getCurrentPosition() + delta;
            video.seekTo((int)Math.min(video.getDuration(), Math.max(0L, target)));
        }
    }
    private static String hostOf(String url) {
        try { String h = Uri.parse(url).getHost(); return h == null ? "unknown host" : h; }
        catch (Exception e) { return "unknown host"; }
    }
    // dispatchKeyEvent runs before focus navigation, so UP/DOWN always
    // changes channel even while a transport control has focus. LEFT/RIGHT
    // and OK belong to the focused transport button.
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int code = e.getKeyCode();
            if (code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (items != null && items.size() > 1) {
                    if (e.getRepeatCount() > 0) return true;
                    saveProgress();
                    resumeMs = 0;
                    pos = code == KeyEvent.KEYCODE_DPAD_UP
                            ? (pos - 1 + items.size()) % items.size()
                            : (pos + 1) % items.size();
                    playCurrent();
                    return true;
                }
            }
            if (errorPanel.getVisibility() == View.VISIBLE
                    && (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT)) {
                retryBtn.requestFocus();
                return true;
            }
            if (code == KeyEvent.KEYCODE_MENU) {
                if (e.getRepeatCount() > 0) return true;
                Item cur = current();
                if (cur != null) { Prefs.toggleFav(this, cur); updateFavLabel(); }
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) {
                View f = getCurrentFocus();
                if (f instanceof Button) return super.dispatchKeyEvent(e);
                togglePlay();
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                View f = getCurrentFocus();
                if (f instanceof Button || f instanceof SeekBar) return super.dispatchKeyEvent(e);
                Item it = current();
                if (it != null && !it.isLive()) {
                    try {
                        int p = video.getCurrentPosition()
                                + (code == KeyEvent.KEYCODE_DPAD_LEFT ? -30000 : 30000);
                        video.seekTo(Math.max(0, p));
                    } catch (Exception ignored) {}
                    return true;
                }
            }
        }
        return super.dispatchKeyEvent(e);
    }
}
