package com.leo.iptv;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;

// The same visible action works with a five-button TV remote in every browsing screen.
final class ReturnTicket {
    private final Activity screen;
    private final Button button;
    private final Handler clock = new Handler(Looper.getMainLooper());
    private final Runnable tick = this::refresh;

    ReturnTicket(Activity screen) {
        this.screen = screen;
        button = screen.findViewById(R.id.return_ticket);
        button.setOnFocusChangeListener((v, focused) -> {
            if (screen.hasWindowFocus()) refresh();
        });
        button.setOnClickListener(v -> {
            HeldChannel held = HeldChannel.get(screen, Prefs.currentName(screen));
            if (held != null) Play.returnToChannel(screen, held);
        });
        button.setOnLongClickListener(v -> {
            String profile = Prefs.currentName(screen);
            HeldChannel held = HeldChannel.get(screen, profile);
            if (held == null) return false;
            new AlertDialog.Builder(screen).setTitle(held.item.name)
                    .setMessage("Release this channel from its return shortcut?")
                    .setPositiveButton("Release", (dialog, which) -> {
                        HeldChannel.clearIfCurrent(screen, profile, held.token);
                        refresh();
                    }).setNegativeButton("Keep", null).show();
            return true;
        });
    }
    void refresh() {
        clock.removeCallbacks(tick);
        HeldChannel held = HeldChannel.get(screen, Prefs.currentName(screen));
        if (held == null) {
            button.setVisibility(View.GONE);
            return;
        }
        button.setVisibility(View.VISIBLE);
        long now = System.currentTimeMillis();
        String detail = held.status(now) + (button.hasFocus() ? " · Hold OK to release" : "");
        button.setText("Return to " + held.item.name + "\n" + detail);
        held.notifyIfDue(screen, Prefs.currentName(screen), now);
        button.setContentDescription("Return to " + held.item.name + ". Hold OK to release.");
        clock.postDelayed(tick, held.nextUpdate(now));
    }
    void pause() { clock.removeCallbacks(tick); }
}
