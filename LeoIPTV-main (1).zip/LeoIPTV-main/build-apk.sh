#!/usr/bin/env bash
# Build and verify a signed debug APK without Gradle.
set -euo pipefail
cd "$(dirname "$0")"
root="$PWD"
sdk="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$root/../sdk}}"
bt="$sdk/build-tools/34.0.0"
platform="$sdk/platforms/android-34/android.jar"
out="$root/build/out"
apk="$out/LeoIPTV-v2.3.apk"

if [[ ! -f "$platform" || ! -x "$bt/aapt2" || ! -x "$bt/d8" || ! -x "$bt/zipalign" || ! -x "$bt/apksigner" ]]; then
  echo "Install Android SDK Platform 34 and Build Tools 34.0.0, then set ANDROID_HOME to that SDK directory." >&2
  exit 1
fi
if [[ -n "${JAVA_HOME:-}" ]]; then
  export PATH="$JAVA_HOME/bin:$PATH"
elif [[ -x "$root/../jdk/bin/javac" ]]; then
  export JAVA_HOME="$root/../jdk"
  export PATH="$JAVA_HOME/bin:$PATH"
fi
command -v javac >/dev/null || { echo "Set JAVA_HOME to a JDK 17 or newer." >&2; exit 1; }

key="${LEO_DEBUG_KEYSTORE:-$root/../debug.keystore}"
if [[ ! -f "$key" && -z "${LEO_DEBUG_KEYSTORE:-}" ]]; then
  key="$HOME/.android/debug.keystore"
fi
if [[ ! -f "$key" ]]; then
  mkdir -p "$(dirname "$key")"
  keytool -genkeypair -keystore "$key" -storepass android -keypass android \
    -alias androiddebugkey -dname "CN=Android Debug,O=Android,C=US" \
    -keyalg RSA -keysize 2048 -validity 10000
fi

mkdir -p "$out"
stage="$(mktemp -d "$out/.build.XXXXXXXX")"
trap 'rm -rf "$stage"' EXIT
mkdir -p "$stage/gen" "$stage/classes" "$stage/dex"
"$bt/aapt2" compile --dir app/res -o "$stage/resources.zip"
"$bt/aapt2" link -o "$stage/base.apk" -I "$platform" --manifest app/AndroidManifest.xml \
  --java "$stage/gen" "$stage/resources.zip" --min-sdk-version 24 --target-sdk-version 34 \
  --version-code 6 --version-name 2.3
mapfile -d '' sources < <(find app/java "$stage/gen" -name '*.java' -print0)
javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$platform" -d "$stage/classes" "${sources[@]}"
jar cf "$stage/classes.jar" -C "$stage/classes" .
"$bt/d8" --lib "$platform" --min-api 24 --output "$stage/dex" "$stage/classes.jar"
(cd "$stage/dex" && zip -q -j "$stage/base.apk" classes*.dex)
"$bt/zipalign" -f 4 "$stage/base.apk" "$stage/aligned.apk"
"$bt/apksigner" sign --ks "$key" --ks-pass pass:android --key-pass pass:android \
  --out "$stage/signed.apk" "$stage/aligned.apk"
"$bt/apksigner" verify --verbose "$stage/signed.apk"
"$bt/zipalign" -c 4 "$stage/signed.apk"
mv "$stage/signed.apk" "$apk"
echo "Built $apk"
